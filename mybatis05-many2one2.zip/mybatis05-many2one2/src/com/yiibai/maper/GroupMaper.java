package com.yiibai.maper;

import com.yiibai.pojo.Group;

public interface GroupMaper {

	public Group getGroup(int i);

	public void insertGroup(Group group);

}
