package com.yiibai.maper;

import java.util.List;

import com.yiibai.pojo.Group;
import com.yiibai.pojo.User;
import com.yiibai.pojo.UserGroup;

public interface UserGroupMaper {

	public void insertUserGroup(UserGroup userGroup);
	public List<User> getUsersByGroupId(int id);
	public List<Group> getGroupsByUserId(int id);
}
