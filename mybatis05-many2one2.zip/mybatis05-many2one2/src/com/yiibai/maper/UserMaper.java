package com.yiibai.maper;

import java.util.List;

import com.yiibai.pojo.User;

public interface UserMaper {

	public void insertUser(User user);
	public List<User> getUser(int id);
}
