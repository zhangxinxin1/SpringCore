package com.yiibai.pojo;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.Priority;

/** 
 * @describe: Group
 * @author: Yiibai 
 * @version: V1.0
 * @copyright http://www.yiibai.com
 */  
public class Group {
	private int groupId;
	private String groupName;
	private List<User> users;
	public static Logger log=Logger.getLogger(Group.class);
	@SuppressWarnings("deprecation")
	public Group(){
		log.log(Priority.INFO, "��־����:Group���󱻴�����");
	}
	public List<User> getUsers() {
		return users;
	}
	public void setUsers(List<User> users) {
		this.users = users;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
}