package com.yiibai.pojo;

import org.apache.log4j.Logger;
import org.apache.log4j.Priority;

public class UserGroup {
	private int userId;  
    private int groupId;
    public static Logger log=Logger.getLogger(UserGroup.class);
	@SuppressWarnings("deprecation")
	public UserGroup(){
		log.log(Priority.INFO, "��־����:UserGroup���󱻴�����");
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
 
    
}